package org.nrg.xnat.restlet.extensions;

import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.nrg.framework.exceptions.NrgServiceError;
import org.nrg.framework.exceptions.NrgServiceRuntimeException;
import org.nrg.xdat.XDAT;
import org.nrg.xft.collections.XftFieldExclusionList;
import org.nrg.xft.entities.XftFieldExclusion;
import org.nrg.xft.entities.XftFieldExclusionScope;
import org.nrg.xnat.restlet.XNATApplication;
import org.nrg.xnat.restlet.XnatRestlet;
import org.nrg.xnat.restlet.resources.SecureResource;
import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.DomRepresentation;
import org.restlet.resource.Representation;
import org.restlet.resource.ResourceException;
import org.restlet.resource.StringRepresentation;
import org.restlet.resource.Variant;

/**
 * Mapped to the following URLs in {@link XNATApplication}:
 * <ul>
 * <li> <tt>/services/mail/send</tt> is basic mail send. Parameters to the REST
 * call should be in the form body.</li>
 * <li> <tt>/services/mail/send/{USER_IDS}/{SUBJECT}/{HTML}</tt> sends an email
 * to the users in the <tt>USER_IDS</tt> list with the indicated
 * <tt>SUBJECT</tt> and <tt>HTML</tt> message body. The form body can contain a
 * binary payload, e.g. an image, that will be sent along with the message as an
 * attachment.</li>
 * </ul>
 * 
 * @author Rick Herrick <rick.herrick@wustl.edu>
 */

@XnatRestlet({"/services/filter/{FILTER_ID}", "/services/filters/{SCOPE}", "/services/filters/{SCOPE}/{TARGET_ID}"})
public class FiltersRestlet extends SecureResource {

    public FiltersRestlet(Context context, Request request, Response response) {
        super(context, request, response);
        setModifiable(true);
        this.getVariants().add(new Variant(MediaType.APPLICATION_JSON));
        this.getVariants().add(new Variant(MediaType.TEXT_XML));

        String filterId = (String) getRequest().getAttributes().get("FILTER_ID");

        if (StringUtils.isBlank(filterId)) {
            String scopeStr = (String) getRequest().getAttributes().get("SCOPE");
            if (StringUtils.isBlank(scopeStr)) {
                throw new NrgServiceRuntimeException(NrgServiceError.InvalidRestServiceParameters, "You must specify a filter ID or scope and optional target ID for this REST service.");
            }
            _scope = XftFieldExclusionScope.valueOf(scopeStr);
            if (_scope != XftFieldExclusionScope.System) {
                _targetId = (String) getRequest().getAttributes().get("TARGET_ID");
                if (StringUtils.isBlank(_targetId)) {
                    throw new NrgServiceRuntimeException(NrgServiceError.InvalidRestServiceParameters, "You must specify a target ID when requesting non-system-scoped exclusions.");
                }
            }
            try {
                Representation entity = getRequest().getEntity();
                if (entity != null && entity.isAvailable() && entity.getSize() > 0) {
                    _expression = entity.getText();
                }
            } catch (IOException exception) {
                respondToException(exception, Status.CLIENT_ERROR_NOT_ACCEPTABLE);
            }
        } else {
            _filterId = Integer.parseInt(filterId);
        }
        if (_log.isDebugEnabled()) {
            if (_filterId < 0) {
                if (StringUtils.isBlank(_targetId)) {
                    _log.debug("Instantiated FiltersRestlet instance to " + request.getMethod() + " for system expressions.");
                } else {
                    _log.debug("Instantiated FiltersRestlet instance to " + request.getMethod() + " for " + _scope.toString() + ": " + _targetId);
                }
                if (!StringUtils.isBlank(_expression)) {
                    _log.debug("Found expression: " + _expression);
                }
            } else {
                _log.debug("Instantiated FiltersRestlet instance to " + request.getMethod() + " filter ID: " + filterId);
            }
        }
    }

    @Override
    public Representation represent(Variant variant) throws ResourceException {
        final MediaType mediaType = overrideVariant(variant);
        if (_filterId < 0) {
            XftFieldExclusionList exclusions;
            if (_scope != XftFieldExclusionScope.System) {
                exclusions = new XftFieldExclusionList(XDAT.getExclusionService().getExclusionsForScopedTarget(_scope, _targetId));
            } else {
                exclusions = new XftFieldExclusionList(XDAT.getExclusionService().getSystemExclusions());
            }
            
            if (mediaType.equals(MediaType.APPLICATION_JSON)) {
                try {
                    return new StringRepresentation("{\"ResultSet\":{\"Result\":" + new ObjectMapper().writeValueAsString(exclusions) + ", \"title\": \"Filters\"}}");
                } catch (IOException exception) {
                    throw new NrgServiceRuntimeException(NrgServiceError.Unknown, "Something went wrong converting filters to JSON.", exception);
                }
            } else {
                return new DomRepresentation(MediaType.TEXT_XML, XDAT.getMarshallerCacheService().marshalToDocument(exclusions));
            }
        } else {
            XftFieldExclusion exclusion = XDAT.getExclusionService().retrieve(_filterId);

            if (mediaType.equals(MediaType.APPLICATION_JSON)) {
                try {
                    return new StringRepresentation("{\"ResultSet\":{\"Result\":" + new ObjectMapper().writeValueAsString(exclusion) + ", \"title\": \"Filter " + _filterId + "\"}}");
                } catch (IOException exception) {
                    throw new NrgServiceRuntimeException(NrgServiceError.Unknown, "Something went wrong converting a filter to JSON.", exception);
                }
            } else {
                return new DomRepresentation(MediaType.TEXT_XML, XDAT.getMarshallerCacheService().marshalToDocument(exclusion));
            }
        }
    }

    @Override
    public void handlePost() {
        createExpression();
    }

    @Override
    public void handlePut() {
        createExpression();
    }

    @Override
    public void handleDelete() {
        _log.debug("Got a request to delete filter with ID: " + _filterId);
        XftFieldExclusion exclusion = XDAT.getExclusionService().retrieve(_filterId);
        _scope = exclusion.getScope();
        if (_scope != XftFieldExclusionScope.System) {
            _targetId = exclusion.getTargetId();
        }
        XDAT.getExclusionService().delete(_filterId);
        _filterId = -1;
        returnDefaultRepresentation();
    }

    private void createExpression() {
        XftFieldExclusion exclusion = XDAT.getExclusionService().newEntity();
        exclusion.setScope(_scope);
        if (_scope != XftFieldExclusionScope.System) {
            exclusion.setTargetId(_targetId);
        }
        exclusion.setPattern(_expression);
        XDAT.getExclusionService().create(exclusion);
        returnDefaultRepresentation();
    }

    private static final Log _log = LogFactory.getLog(FiltersRestlet.class);
    private int _filterId = -1;
    private XftFieldExclusionScope _scope;
    private String _targetId;
    private String _expression;
}
