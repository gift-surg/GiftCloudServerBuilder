/*******************************************************************************
 * Set of functions to facilitate project filter management via AJAX
 */

var removeButtonFormatter = function(elCell, oRecord, oColumn, oData) {
	elCell.innerHTML = "<input type=\"button\" ONCLICK=\"window.filterManager.removeFilter('" + oRecord.getData("id") + "');\" value=\"Remove\"/>";
};

function prependLoader(div_id, msg) {
	if (div_id.id == undefined) {
		var div = document.getElementById(div_id);
	} else {
		var div = div_id;
	}
	var loader_div = document.createElement("div");
	loader_div.innerHTML = msg;
	div.parentNode.insertBefore(loader_div, div);
	return new XNATLoadingGIF(loader_div);
}

function FilterManager(filter_mgmt_div_id, pID) {
	this.filterSvcUrl = serverRoot + '/data/services/filter/';
	var filtersSvcUrl = serverRoot + '/data/services/filters/';

	if (pID) {
		this.pID = pID;
		this.scopedFiltersSvcUrl = filtersSvcUrl + 'Project/' + pID;
	} else {
		this.scopedFiltersSvcUrl = filtersSvcUrl + 'System/';
	}

	this.filter_mgmt_div = document.getElementById(filter_mgmt_div_id);
	this.filter_table_div = document.createElement("div");
	this.filter_table_div.id = "filter_table";
	this.filter_mgmt_div.appendChild(this.filter_table_div);

	this.filterColumnDefs = [ {key : "button", label : "Remove", formatter : removeButtonFormatter},
                       		  {key : "pattern", label : "Pattern", sortable : true } ];

	this.init = function() {
		this.initLoader = prependLoader(this.filter_table_div, pID ? "Loading filters for project " + pID + "..." : "Loading system filters...");
		this.initLoader.render();
		// load from search xml from server
		this.initCallback = {
			success : this.completeInit,
			failure : this.initFailure,
			scope : this
		};

		var getUrl = this.scopedFiltersSvcUrl + '?format=json&stamp=' + (new Date()).getTime();
		YAHOO.util.Connect.asyncRequest('GET', getUrl, this.initCallback, null, this);
	};

	this.initFailure = function(o) {
		this.initLoader.close();
		this.displayError("ERROR " + o.status + ": Failed to load filter list.");
		if (o.status == 401) {
			alert("WARNING: Your session has expired.  You will need to re-login and navigate to the content.");
			window.location = serverRoot + "/app/template/Login.vm";
		}
	};

	this.completeInit = function(o) {
		try {
			this.filterResultSet = eval("(" + o.responseText + ")");
			this.render();
		} catch (e) {
			this.displayError("ERROR " + o.status + ": Failed to parse filter list.");
		}
		this.initLoader.close();
	};

	this.render = function() {
		this.filterDataSource = new YAHOO.util.DataSource(this.filterResultSet.ResultSet.Result);
		this.filterDataSource.responseType = YAHOO.util.DataSource.TYPE_JSARRAY;
		this.filterDataSource.responseSchema = {
			fields : [ "id", "pattern" ]
		};

		if (this.filterResultSet.ResultSet.Result.length > 6)
			var config = {
				scrollable : true,
				height : "180"
			};
		this.filterDataTable = new YAHOO.widget.DataTable("filter_table", this.filterColumnDefs, this.filterDataSource, config);
	};

	this.setFormDisabled = function(value) {
		var filter_add_div = document.getElementById("filter_add_div");
		var inputs = filter_add_div.getElementsByTagName("input");
		for ( var inputCounter in inputs) {
			inputs[inputCounter].disabled = value;
		}

		var selects = filter_add_div.getElementsByTagName("select");
		for ( var selectsCounter in selects) {
			selects[selectsCounter].disabled = value;
		}
	};

	this.resetForm = function() {
		document.getElementById("expression").value = '';
		document.getElementById("expression").focus();
	};

	this.completeAdd = function(o) {
		this.completeInit(o);
		this.setFormDisabled(false);
		this.resetForm();
	};

	this.addFailure = function(o) {
		if (o.status == 401) {
			alert("WARNING: Your session has expired.  You will need to re-login and navigate to the content.");
			window.location = serverRoot + "/app/template/Login.vm";
		}
		alert("ERROR " + o.status + ": Operation Failed.");
		this.setFormDisabled(false);
	};

	this.addExpressionFromForm = function() {
		var expression = document.getElementById("expression").value;
		if (expression != "") {
			this.addExpression(expression);
		}
	};

	this.addExpression = function(expression) {
		if (expression != undefined) {
			this.setFormDisabled(true);
			this.insertCallback = {
				success : this.completeAdd,
				failure : this.addFailure,
				scope : this
			};
			YAHOO.util.Connect.asyncRequest('POST', this.scopedFiltersSvcUrl, this.insertCallback, escape(expression), this);
		} else {
			alert("You need to enter a value into the expression box to create a new expression.");
		}
	};

	this.completeRemoval = function(o) {
		this.completeInit(o);
		this.setFormDisabled(false);
	};

	this.removeFilter = function(id) {
		this.setFormDisabled(true);

		this.deleteCallback = {
			success : this.completeRemoval,
			failure : this.addFailure,
			scope : this
		};
		YAHOO.util.Connect.asyncRequest('DELETE', this.filterSvcUrl + id, this.deleteCallback, null, this);
	};

	this.displayError = function(errorMsg) {
		this.filter_table_div.className = "error";
		this.filter_table_div.innerHTML = errorMsg;
	};

	this.init();
}
